import streamlit as st
from ultralytics import YOLO
import cv2
from PIL import Image
import numpy as np

@st.cache_resource
def load_model():
    model = YOLO('models/roadscan_model.pt')  # Load local YOLO model
    return model

model = load_model()

st.title("RoadScan: Road Defect Detection")
uploaded_file = st.file_uploader("Upload a road image", type=["jpg", "jpeg", "png"])

if uploaded_file:
    image = Image.open(uploaded_file).convert('RGB')
    img_np = np.array(image)

    results = model.predict(img_np)

    for r in results:
        res_plotted = r.plot()  # Get annotated image
        st.image(res_plotted, caption="Detected Road Defects", use_column_width=True")
